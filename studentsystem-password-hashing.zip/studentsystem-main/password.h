#ifndef PASSWORD_H
#define PASSWORD_H

#include <string>

// Creates a salted PBKDF2-HMAC-SHA256 password representation.
std::string hashPassword(const std::string& password);

// Verifies a password against a stored PBKDF2 representation.
bool verifyPassword(const std::string& password, const std::string& storedHash);

// Identifies passwords stored using the current hash format.
bool isPasswordHash(const std::string& value);

#endif
