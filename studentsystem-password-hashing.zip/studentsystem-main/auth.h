#ifndef AUTH_H
#define AUTH_H

#include <string>

bool login(const std::string& username, const std::string& password,
           int& userId, std::string& role);

#endif
