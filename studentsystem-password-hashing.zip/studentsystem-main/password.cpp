#include "password.h"

#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

#include <array>
#include <iomanip>
#include <sstream>
#include <vector>

namespace
{
constexpr int SALT_SIZE = 16;
constexpr int HASH_SIZE = 32;
constexpr int ITERATIONS = 210000;
const char* HASH_PREFIX = "$pbkdf2-sha256$";

std::string toHex(const unsigned char* data, std::size_t length)
{
    std::ostringstream output;
    output << std::hex << std::setfill('0');
    for (std::size_t i = 0; i < length; ++i)
        output << std::setw(2) << static_cast<unsigned int>(data[i]);
    return output.str();
}

bool fromHex(const std::string& hex, std::vector<unsigned char>& output)
{
    if (hex.empty() || hex.size() % 2 != 0)
        return false;

    output.clear();
    output.reserve(hex.size() / 2);

    for (std::size_t i = 0; i < hex.size(); i += 2)
    {
        try
        {
            const unsigned int value = static_cast<unsigned int>(std::stoul(hex.substr(i, 2), nullptr, 16));
            output.push_back(static_cast<unsigned char>(value));
        }
        catch (...)
        {
            return false;
        }
    }
    return true;
}

bool deriveHash(const std::string& password, const unsigned char* salt,
                int saltLength, int iterations, unsigned char* output,
                int outputLength)
{
    return PKCS5_PBKDF2_HMAC(password.c_str(), static_cast<int>(password.size()),
                             salt, saltLength, iterations, EVP_sha256(),
                             outputLength, output) == 1;
}
}

bool isPasswordHash(const std::string& value)
{
    return value.compare(0, std::string(HASH_PREFIX).size(), HASH_PREFIX) == 0;
}

std::string hashPassword(const std::string& password)
{
    std::array<unsigned char, SALT_SIZE> salt{};
    std::array<unsigned char, HASH_SIZE> derived{};

    if (RAND_bytes(salt.data(), static_cast<int>(salt.size())) != 1)
        return {};

    if (!deriveHash(password, salt.data(), static_cast<int>(salt.size()),
                    ITERATIONS, derived.data(), static_cast<int>(derived.size())))
        return {};

    return std::string(HASH_PREFIX) + "i=" + std::to_string(ITERATIONS) + "$" +
           toHex(salt.data(), salt.size()) + "$" +
           toHex(derived.data(), derived.size());
}

bool verifyPassword(const std::string& password, const std::string& storedHash)
{
    if (!isPasswordHash(storedHash))
        return false;

    const std::string remainder = storedHash.substr(std::string(HASH_PREFIX).size());
    const std::size_t firstSeparator = remainder.find('$');
    const std::size_t secondSeparator = firstSeparator == std::string::npos
                                            ? std::string::npos
                                            : remainder.find('$', firstSeparator + 1);
    if (firstSeparator == std::string::npos || secondSeparator == std::string::npos)
        return false;

    const std::string iterationText = remainder.substr(0, firstSeparator);
    if (iterationText.compare(0, 2, "i=") != 0)
        return false;

    int iterations = 0;
    try
    {
        std::size_t parsed = 0;
        iterations = std::stoi(iterationText.substr(2), &parsed);
        if (parsed != iterationText.size() - 2 || iterations < 10000 || iterations > 2000000)
            return false;
    }
    catch (...)
    {
        return false;
    }

    std::vector<unsigned char> salt;
    std::vector<unsigned char> expected;
    if (!fromHex(remainder.substr(firstSeparator + 1,
                                  secondSeparator - firstSeparator - 1), salt) ||
        !fromHex(remainder.substr(secondSeparator + 1), expected) ||
        salt.size() != SALT_SIZE || expected.size() != HASH_SIZE)
        return false;

    std::array<unsigned char, HASH_SIZE> actual{};
    if (!deriveHash(password, salt.data(), static_cast<int>(salt.size()),
                    iterations, actual.data(), static_cast<int>(actual.size())))
        return false;

    return CRYPTO_memcmp(actual.data(), expected.data(), actual.size()) == 0;
}
