#ifndef FEES_H
#define FEES_H

void updateFee();
void viewAllFees();
void viewStudentFee(int studentId);

#endif
