#include "fees.h"
#include "database.h"
#include <iostream>
using namespace std;

void updateFee()
{
    int id;
    double totalFee, paidFee;

    cout << "Student ID: ";
    cin >> id;
    cout << "Total fee: ";
    cin >> totalFee;
    cout << "Fee paid: ";
    cin >> paidFee;

    if (id <= 0 || totalFee < 0 || paidFee < 0 || paidFee > totalFee)
    {
        cout << "Invalid fee amounts. Paid fee cannot exceed total fee.\n";
        return;
    }

    sqlite3_stmt* stmt = nullptr;
    const char* sql =
        "INSERT INTO fees(student_id,total_fee,paid_fee) VALUES(?,?,?) "
        "ON CONFLICT(student_id) DO UPDATE SET "
        "total_fee=excluded.total_fee,paid_fee=excluded.paid_fee";

    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, id);
    sqlite3_bind_double(stmt, 2, totalFee);
    sqlite3_bind_double(stmt, 3, paidFee);

    if (sqlite3_step(stmt) == SQLITE_DONE && sqlite3_changes(db) > 0)
        cout << "Fee details updated successfully.\n";
    else
        cout << "Student ID not found or update failed.\n";

    sqlite3_finalize(stmt);
}

void viewStudentFee(int studentId)
{
    sqlite3_stmt* stmt = nullptr;
    sqlite3_prepare_v2(db,
        "SELECT total_fee,paid_fee FROM fees WHERE student_id=?",
        -1, &stmt, nullptr);
    sqlite3_bind_int(stmt, 1, studentId);

    if (sqlite3_step(stmt) == SQLITE_ROW)
    {
        double total = sqlite3_column_double(stmt, 0);
        double paid = sqlite3_column_double(stmt, 1);
        double balance = total - paid;

        cout << "\n--- FEE DETAILS ---\n"
             << "Total fee: " << total
             << "\nPaid fee: " << paid
             << "\nBalance: " << balance
             << "\nStatus: " << (balance <= 0.009 ? "NIL" : "PENDING") << '\n';
    }
    else
        cout << "Fee details not found.\n";

    sqlite3_finalize(stmt);
}

void viewAllFees()
{
    sqlite3_stmt* stmt = nullptr;
    const char* sql =
        "SELECT s.id,s.name,COALESCE(f.total_fee,0),COALESCE(f.paid_fee,0) "
        "FROM students s LEFT JOIN fees f ON s.id=f.student_id ORDER BY s.id";

    sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr);
    cout << "\n--- ALL STUDENT FEES ---\n";

    while (sqlite3_step(stmt) == SQLITE_ROW)
    {
        double total = sqlite3_column_double(stmt, 2);
        double paid = sqlite3_column_double(stmt, 3);
        double balance = total - paid;

        cout << "\nID: " << sqlite3_column_int(stmt, 0)
             << "\nName: " << sqlite3_column_text(stmt, 1)
             << "\nTotal fee: " << total
             << "\nPaid fee: " << paid
             << "\nBalance: " << balance
             << "\nStatus: " << (balance <= 0.009 ? "NIL" : "PENDING") << '\n';
    }

    sqlite3_finalize(stmt);
}
