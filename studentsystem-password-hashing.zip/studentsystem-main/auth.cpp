#include "auth.h"
#include "database.h"
#include "password.h"

bool login(const std::string& username, const std::string& password,
           int& userId, std::string& role)
{
    sqlite3_stmt* stmt = nullptr;
    const char* sql = "SELECT id, role, password FROM users WHERE username=?";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return false;

    sqlite3_bind_text(stmt, 1, username.c_str(), -1, SQLITE_TRANSIENT);

    int foundUserId = -1;
    std::string storedRole;
    std::string storedPassword;
    if (sqlite3_step(stmt) == SQLITE_ROW)
    {
        foundUserId = sqlite3_column_int(stmt, 0);
        const unsigned char* roleText = sqlite3_column_text(stmt, 1);
        const unsigned char* passwordText = sqlite3_column_text(stmt, 2);
        storedRole = roleText ? reinterpret_cast<const char*>(roleText) : "";
        storedPassword = passwordText ? reinterpret_cast<const char*>(passwordText) : "";
    }
    sqlite3_finalize(stmt);

    if (foundUserId < 0)
        return false;

    bool passwordMatches = false;
    if (isPasswordHash(storedPassword))
    {
        passwordMatches = verifyPassword(password, storedPassword);
    }
    else
    {
        // Backward compatibility: upgrade a legacy plain-text password
        // immediately after its first successful login.
        passwordMatches = (password == storedPassword);
        if (passwordMatches)
        {
            const std::string upgradedHash = hashPassword(password);
            if (upgradedHash.empty())
                return false;

            sqlite3_stmt* updateStmt = nullptr;
            const char* updateSQL = "UPDATE users SET password=? WHERE id=?";
            if (sqlite3_prepare_v2(db, updateSQL, -1, &updateStmt, nullptr) != SQLITE_OK)
                return false;

            sqlite3_bind_text(updateStmt, 1, upgradedHash.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(updateStmt, 2, foundUserId);
            const bool updated = sqlite3_step(updateStmt) == SQLITE_DONE && sqlite3_changes(db) > 0;
            sqlite3_finalize(updateStmt);
            if (!updated)
                return false;
        }
    }

    if (passwordMatches)
    {
        userId = foundUserId;
        role = storedRole;
    }
    return passwordMatches;
}
