# Modular Student Management System (C++ and SQLite)

## Project structure

- `main.cpp` - Main program and student menu
- `database.h / database.cpp` - Opens database and creates tables
- `auth.h / auth.cpp` - Admin and student login authentication
- `password.h / password.cpp` - Salted PBKDF2-HMAC-SHA256 password hashing and verification
- `student.h / student.cpp` - Add and display student profiles
- `attendance.h / attendance.cpp` - Update and view attendance
- `fees.h / fees.cpp` - Update and view fee details
- `reports.h / reports.cpp` - Students scoring below 35%
- `admin.h / admin.cpp` - Admin menu
- `students.db` - Created automatically when the program runs

## Features

### Admin
1. Add student accounts and profiles
2. Display all students
3. Update student attendance
4. View all attendance percentages
5. View students whose marks are below 35%
6. Update student fee details
7. View all student fee details

### Student
1. View own profile and marks
2. View own attendance
3. View own fee details and NIL/PENDING status

## Demo credentials
- Admin: `admin` / `1234`
- Demo student: `student` / `1234`

Admin can create additional student accounts.

## Database tables
- `users`: account username, password and role
- `students`: student profile and marks
- `attendance`: attended and total class counts
- `fees`: total fee and paid fee

Attendance percentage = attended classes / total classes * 100.
Failed list is based on marks below 35%.
Fee status is `NIL` if no balance remains, otherwise `PENDING`.

## Compile in GitHub Codespaces / Ubuntu

Install dependencies:
```bash
sudo apt update
sudo apt install g++ libsqlite3-dev libssl-dev -y
```

Compile all source files together:
```bash
g++ -std=c++17 main.cpp database.cpp auth.cpp password.cpp student.cpp attendance.cpp fees.cpp reports.cpp admin.cpp -lsqlite3 -lcrypto -o main
```

Run:
```bash
./main
```

**Important:** Do not compile only `main.cpp`; all `.cpp` module files must be included in the compile command.

## Password security
- Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes, not plain text.
- Each password receives a cryptographically random 16-byte salt.
- The hash uses 210,000 PBKDF2 iterations and SHA-256.
- Login verifies the entered password against the stored salt and hash.
- Existing legacy plain-text passwords are upgraded to hashes after a successful login.
- OpenSSL is required for secure random salt generation and PBKDF2; install `libssl-dev` on Ubuntu.
- Demo credentials remain `admin` / `1234` and `student` / `1234` for a fresh database.
