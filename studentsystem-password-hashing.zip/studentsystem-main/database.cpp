#include "database.h"
#include "password.h"
#include <iostream>

sqlite3* db = nullptr;

void runSQL(const std::string& sql)
{
    char* error = nullptr;
    if (sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK)
    {
        std::cout << "Database error: " << error << '\n';
        sqlite3_free(error);
    }
}

bool openDatabase()
{
    if (sqlite3_open("students.db", &db) != SQLITE_OK)
    {
        std::cout << "Cannot open database.\n";
        return false;
    }
    return true;
}

void closeDatabase()
{
    if (db != nullptr)
    {
        sqlite3_close(db);
        db = nullptr;
    }
}

void setupDatabase()
{
    runSQL("PRAGMA foreign_keys=ON;");

    runSQL("CREATE TABLE IF NOT EXISTS users("
           "id INTEGER PRIMARY KEY AUTOINCREMENT,"
           "username TEXT UNIQUE NOT NULL,"
           "password TEXT NOT NULL,"
           "role TEXT NOT NULL);");

    runSQL("CREATE TABLE IF NOT EXISTS students("
           "id INTEGER PRIMARY KEY AUTOINCREMENT,"
           "user_id INTEGER UNIQUE NOT NULL,"
           "name TEXT NOT NULL,"
           "course TEXT NOT NULL,"
           "marks REAL DEFAULT 0,"
           "FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);");

    runSQL("CREATE TABLE IF NOT EXISTS attendance("
           "student_id INTEGER PRIMARY KEY,"
           "attended INTEGER DEFAULT 0,"
           "total INTEGER DEFAULT 0,"
           "FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE);");

    runSQL("CREATE TABLE IF NOT EXISTS fees("
           "student_id INTEGER PRIMARY KEY,"
           "total_fee REAL DEFAULT 0,"
           "paid_fee REAL DEFAULT 0,"
           "FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE);");

    // Default demonstration accounts are inserted with salted password hashes.
    // Existing accounts are not overwritten; legacy plain-text passwords are
    // upgraded after the account successfully logs in.
    sqlite3_stmt* userStmt = nullptr;
    const char* userSQL = "INSERT OR IGNORE INTO users(username,password,role) VALUES(?,?,?)";
    if (sqlite3_prepare_v2(db, userSQL, -1, &userStmt, nullptr) == SQLITE_OK)
    {
        const char* usernames[] = {"admin", "student"};
        const char* roles[] = {"admin", "student"};
        for (int i = 0; i < 2; ++i)
        {
            const std::string demoPasswordHash = hashPassword("1234");
            if (demoPasswordHash.empty())
            {
                std::cout << "Could not hash demo account password: " << usernames[i] << '\n';
                continue;
            }

            sqlite3_reset(userStmt);
            sqlite3_clear_bindings(userStmt);
            sqlite3_bind_text(userStmt, 1, usernames[i], -1, SQLITE_STATIC);
            sqlite3_bind_text(userStmt, 2, demoPasswordHash.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_text(userStmt, 3, roles[i], -1, SQLITE_STATIC);
            if (sqlite3_step(userStmt) != SQLITE_DONE)
                std::cout << "Could not create demo account: " << usernames[i] << '\n';
        }
        sqlite3_finalize(userStmt);
    }
    else
    {
        std::cout << "Could not prepare demo account creation.\n";
    }

    runSQL("INSERT OR IGNORE INTO students(user_id,name,course,marks) "
           "SELECT id,'Demo Student','Computer Engineering',85 "
           "FROM users WHERE username='student';");

    // Add default attendance and fee rows for existing students.
    runSQL("INSERT OR IGNORE INTO attendance(student_id) SELECT id FROM students;");
    runSQL("INSERT OR IGNORE INTO fees(student_id) SELECT id FROM students;");
}
